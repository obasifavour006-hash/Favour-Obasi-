# Favour Obasi | AI Video Creator portfolio

A static site (HTML, CSS, JavaScript, Three.js from cdnjs). No build step, so it runs on GitHub Pages as is.

## Deploy
1. Create a GitHub repository and push this folder to the `main` branch.
2. In the repo go to Settings > Pages > Build and deployment > Source and choose **GitHub Actions**.
3. The workflow in `.github/workflows/pages.yml` publishes the site. All paths are relative, so no base path needs changing.

## Update the work
Everything about the videos lives in `js/projects.js`: title, category, description, `video`, `poster`, `start` (preview start in seconds) and `dur` (preview length).
- Add a video: put the MP4 in `videos/`, make a poster, add one entry.
- Poster frame: `ffmpeg -ss 5 -i videos/NAME.mp4 -frames:v 1 -vf scale=-2:480 posters/NAME.jpg`
- Portrait: replace `images/favour.jpg`.

## Size limits
GitHub blocks single files over 100 MB and recommends repos under 1 GB. Current videos total about 105 MB, all individually small. For larger files, compress with H.264 or host them elsewhere and put the full URL in `video`.
